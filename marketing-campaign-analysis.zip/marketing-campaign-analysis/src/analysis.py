"""
Marketing Campaign Performance - extended analysis.

Goes beyond the descriptive "group-by + dashboard" work that is typically done on this
dataset (Power BI / KNIME / Kaggle EDA) and adds:

  1. Data-integrity audit (incl. Campaign_Type vs Channel_Used consistency)
  2. Derived efficiency KPIs (CTR, CPC, cost per conversion, implied profit)
  3. Statistical significance + effect sizes for every segment dimension (BH-corrected)
  4. Bootstrap confidence intervals for segment means
  5. "Best combination" search with a permutation null (is the top combo real or noise?)
  6. Distribution / independence diagnostics (is the data synthetic-like?)
  7. Time-series: monthly trend, day-of-week, seasonality tests
  8. Predictive modelling with honest cross-validation vs. a baseline
  9. Efficiency frontier (cost vs. ROI) per company

Run:  python src/analysis.py            (from the repository root)
"""
from __future__ import annotations

import itertools
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy import stats
from sklearn.dummy import DummyClassifier, DummyRegressor
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.inspection import permutation_importance
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "marketing_campaign_dataset.csv"
FIG = ROOT / "outputs" / "figures"
TAB = ROOT / "outputs" / "tables"
FIG.mkdir(parents=True, exist_ok=True)
TAB.mkdir(parents=True, exist_ok=True)

RNG = np.random.default_rng(42)
sns.set_theme(style="whitegrid", context="notebook")
CATS = ["Company", "Campaign_Type", "Target_Audience", "Duration", "Channel_Used",
        "Location", "Language", "Customer_Segment"]
METRICS = ["ROI", "Conversion_Rate", "Engagement_Score", "Acquisition_Cost", "CTR",
           "Cost_per_Click", "Cost_per_Conversion"]
FINDINGS: dict = {}


def save_fig(name: str) -> None:
    plt.tight_layout()
    plt.savefig(FIG / name, dpi=140)
    plt.close()


def save_tab(df: pd.DataFrame, name: str, index: bool = True) -> None:
    df.to_csv(TAB / name, index=index)


# --------------------------------------------------------------------------- 1. load + audit
def load() -> pd.DataFrame:
    df = pd.read_csv(DATA)
    df["Acquisition_Cost"] = (df["Acquisition_Cost"].str.replace(r"[$,]", "", regex=True).astype(float))
    df["Date"] = pd.to_datetime(df["Date"])
    df["Duration_Days"] = df["Duration"].str.extract(r"(\d+)").astype(int)
    # derived KPIs
    df["CTR"] = df["Clicks"] / df["Impressions"]
    df["Conversions"] = df["Clicks"] * df["Conversion_Rate"]
    df["Cost_per_Click"] = df["Acquisition_Cost"] / df["Clicks"]
    df["Cost_per_Conversion"] = df["Acquisition_Cost"] / df["Conversions"]
    df["Cost_per_Day"] = df["Acquisition_Cost"] / df["Duration_Days"]
    # ASSUMPTION: ROI = (revenue - cost) / cost  ->  profit = ROI * cost
    df["Implied_Profit"] = df["ROI"] * df["Acquisition_Cost"]
    df["Month"] = df["Date"].dt.to_period("M").astype(str)
    df["DayOfWeek"] = df["Date"].dt.day_name()
    return df


def audit(df: pd.DataFrame) -> None:
    rep = {
        "rows": len(df),
        "missing_cells": int(df.isna().sum().sum()),
        "duplicate_rows": int(df.drop(columns="Campaign_ID").duplicated().sum()),
        "campaign_id_unique": bool(df["Campaign_ID"].is_unique),
        "date_min": str(df["Date"].min().date()),
        "date_max": str(df["Date"].max().date()),
        "clicks_gt_impressions": int((df["Clicks"] > df["Impressions"]).sum()),
        "cost_min": float(df["Acquisition_Cost"].min()),
        "cost_max": float(df["Acquisition_Cost"].max()),
    }
    # Integrity: do Campaign_Type and Channel_Used make sense together?
    ct = pd.crosstab(df["Campaign_Type"], df["Channel_Used"], normalize="index")
    save_tab(ct.round(4), "campaign_type_by_channel_share.csv")
    illogical = df[((df["Campaign_Type"] == "Email") & (df["Channel_Used"] != "Email")) |
                   ((df["Campaign_Type"] != "Email") & (df["Channel_Used"] == "Email"))]
    rep["email_type_channel_mismatch_rows"] = int(len(illogical))
    rep["email_type_channel_mismatch_pct"] = round(100 * len(illogical) / len(df), 2)
    chi2, p, dof, _ = stats.chi2_contingency(pd.crosstab(df["Campaign_Type"], df["Channel_Used"]))
    n = len(df)
    rep["type_vs_channel_cramers_v"] = round(float(np.sqrt(chi2 / (n * (min(5, 6) - 1)))), 4)
    rep["type_vs_channel_chi2_p"] = float(p)
    FINDINGS["audit"] = rep

    plt.figure(figsize=(8, 4.5))
    sns.heatmap(ct, annot=True, fmt=".2f", cmap="Blues", cbar=False)
    plt.title("Share of each Campaign_Type run on each Channel_Used\n(a logical mapping would be near-diagonal)")
    save_fig("01_campaign_type_vs_channel.png")


# --------------------------------------------------------------------------- 2. descriptive (brief)
def descriptive(df: pd.DataFrame) -> None:
    rows = []
    for c in CATS:
        g = df.groupby(c).agg(campaigns=("Campaign_ID", "size"), roi=("ROI", "mean"),
                              conv=("Conversion_Rate", "mean"), eng=("Engagement_Score", "mean"),
                              cost=("Acquisition_Cost", "mean"), ctr=("CTR", "mean"),
                              cpc=("Cost_per_Click", "mean"),
                              cpa=("Cost_per_Conversion", "mean")).reset_index()
        g.insert(0, "dimension", c)
        g = g.rename(columns={c: "segment"})
        rows.append(g)
    out = pd.concat(rows)
    save_tab(out.round(4), "segment_kpis.csv", index=False)

    fig, axes = plt.subplots(2, 3, figsize=(16, 8))
    for ax, m in zip(axes.flat, ["ROI", "Conversion_Rate", "Engagement_Score",
                                 "Acquisition_Cost", "CTR", "Cost_per_Conversion"]):
        sns.histplot(df[m], bins=40, ax=ax, color="#3b6fb6")
        ax.set_title(m)
    plt.suptitle("Distributions of core and derived metrics", y=1.01)
    save_fig("02_metric_distributions.png")


# --------------------------------------------------------------------------- 3. significance
def eta_squared(groups: list[np.ndarray]) -> float:
    allv = np.concatenate(groups)
    gm = allv.mean()
    ssb = sum(len(g) * (g.mean() - gm) ** 2 for g in groups)
    sst = ((allv - gm) ** 2).sum()
    return float(ssb / sst)


def bh(p: np.ndarray) -> np.ndarray:
    """Benjamini-Hochberg adjusted p-values."""
    p = np.asarray(p)
    n = len(p)
    order = np.argsort(p)
    adj = p[order] * n / (np.arange(n) + 1)
    adj = np.minimum.accumulate(adj[::-1])[::-1]
    out = np.empty(n)
    out[order] = np.clip(adj, 0, 1)
    return out


def significance(df: pd.DataFrame) -> None:
    rows = []
    for c, m in itertools.product(CATS, METRICS):
        groups = [g[m].dropna().to_numpy() for _, g in df.groupby(c)]
        f, p_anova = stats.f_oneway(*groups)
        h, p_kw = stats.kruskal(*groups)
        rows.append({"dimension": c, "metric": m, "F": f, "p_anova": p_anova,
                     "p_kruskal": p_kw, "eta_squared": eta_squared(groups)})
    res = pd.DataFrame(rows)
    res["p_kruskal_BH"] = bh(res["p_kruskal"].to_numpy())
    res["significant_5pct_BH"] = res["p_kruskal_BH"] < 0.05
    save_tab(res.round(6), "significance_tests.csv", index=False)
    FINDINGS["significance"] = {
        "tests_run": int(len(res)),
        "significant_after_BH": int(res["significant_5pct_BH"].sum()),
        "max_eta_squared": float(res["eta_squared"].max()),
        "max_eta_row": res.loc[res["eta_squared"].idxmax(), ["dimension", "metric"]].tolist(),
        "significant_rows": res[res["significant_5pct_BH"]][["dimension", "metric", "eta_squared",
                                                              "p_kruskal_BH"]].round(6).to_dict("records"),
    }

    pv = res.pivot(index="dimension", columns="metric", values="p_kruskal")
    ev = res.pivot(index="dimension", columns="metric", values="eta_squared")
    fig, ax = plt.subplots(1, 2, figsize=(17, 5))
    sns.heatmap(pv, annot=True, fmt=".2f", cmap="RdYlGn", vmin=0, vmax=1, ax=ax[0],
                cbar_kws={"label": "raw Kruskal-Wallis p-value"})
    ax[0].set_title("Is there a real difference between segments?\n(p < 0.05 would be red; 56 tests, none survive BH correction)")
    sns.heatmap(ev, annot=True, fmt=".5f", cmap="Greens", ax=ax[1], cbar_kws={"label": "eta squared"})
    ax[1].set_title("How big is it? (eta squared = share of variance explained)")
    save_fig("03_significance_and_effect_size.png")


# --------------------------------------------------------------------------- 4. bootstrap CIs
def bootstrap_ci(df: pd.DataFrame, n_boot: int = 500) -> None:
    rows = []
    for c in ["Campaign_Type", "Channel_Used"]:
        for seg, g in df.groupby(c):
            v = g["ROI"].to_numpy()
            means = [RNG.choice(v, len(v)).mean() for _ in range(n_boot)]
            rows.append({"dimension": c, "segment": seg, "mean_ROI": v.mean(),
                         "ci_low": np.percentile(means, 2.5), "ci_high": np.percentile(means, 97.5)})
    out = pd.DataFrame(rows)
    save_tab(out.round(4), "bootstrap_roi_ci.csv", index=False)
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.5), sharex=True)
    for ax, c in zip(axes, ["Campaign_Type", "Channel_Used"]):
        d = out[out.dimension == c].sort_values("mean_ROI")
        ax.errorbar(d["mean_ROI"], d["segment"], xerr=[d["mean_ROI"] - d["ci_low"], d["ci_high"] - d["mean_ROI"]],
                    fmt="o", capsize=4, color="#3b6fb6")
        ax.axvline(df["ROI"].mean(), ls="--", color="grey")
        ax.set_title(f"Mean ROI by {c} with 95% bootstrap CI")
        ax.set_xlim(4.9, 5.1)
    save_fig("04_bootstrap_roi_ci.png")


# --------------------------------------------------------------------------- 5. best combo vs null
def combo_search(df: pd.DataFrame, n_perm: int = 200) -> None:
    combo = ["Campaign_Type", "Channel_Used", "Target_Audience"]
    g = df.groupby(combo)["ROI"].agg(["mean", "size"]).reset_index()
    g = g[g["size"] >= 100].sort_values("mean", ascending=False)
    save_tab(g.round(4), "combo_roi_ranking.csv", index=False)
    observed_top = g["mean"].max()
    observed_spread = g["mean"].max() - g["mean"].min()

    keys = df[combo].astype(str).agg("|".join, axis=1).to_numpy()
    uniq, inv = np.unique(keys, return_inverse=True)
    cnt = np.bincount(inv)
    ok = cnt >= 100
    roi = df["ROI"].to_numpy()
    null_top = []
    for _ in range(n_perm):
        s = np.bincount(inv, weights=RNG.permutation(roi))
        m = (s / cnt)[ok]
        null_top.append(m.max())
    null_top = np.array(null_top)
    FINDINGS["combo"] = {
        "n_combos": int(ok.sum()),
        "best_combo": g.iloc[0][combo].tolist(), "best_mean_roi": float(observed_top),
        "best_combo_n": int(g.iloc[0]["size"]),
        "overall_mean_roi": float(roi.mean()),
        "spread_best_minus_worst": float(observed_spread),
        "null_top_mean_95pct": float(np.percentile(null_top, 95)),
        "perm_p_value_top": float((np.sum(null_top >= observed_top) + 1) / (n_perm + 1)),
    }
    plt.figure(figsize=(8, 4.5))
    sns.histplot(null_top, bins=25, color="#9aa7b8", label="Best combo ROI under random shuffling")
    plt.axvline(observed_top, color="crimson", lw=2, label=f"Observed best combo = {observed_top:.3f}")
    plt.legend(); plt.xlabel("Mean ROI of the top combination")
    plt.title("Is the 'best' Type x Channel x Audience combo better than luck?")
    save_fig("05_best_combo_vs_permutation_null.png")


# --------------------------------------------------------------------------- 6. diagnostics
def diagnostics(df: pd.DataFrame) -> None:
    num = ["ROI", "Conversion_Rate", "Engagement_Score", "Acquisition_Cost", "Clicks", "Impressions",
           "Duration_Days", "CTR"]
    sp = df[num].corr(method="spearman")
    save_tab(sp.round(4), "spearman_correlations.csv")
    # CTR is derived from Clicks/Impressions, so exclude it from the "independence" summary
    raw = sp.drop(index="CTR", columns="CTR")
    offdiag = raw.where(~np.eye(len(raw), dtype=bool)).abs()
    plt.figure(figsize=(8, 6))
    sns.heatmap(sp, annot=True, fmt=".2f", cmap="coolwarm", center=0, vmin=-1, vmax=1)
    plt.title("Spearman correlations (core metrics)")
    save_fig("06_correlations.png")

    def ks_uniform(x, lo, hi):
        return float(stats.kstest((x - lo) / (hi - lo), "uniform").pvalue)

    uni = {
        "ROI~U(2,8)": ks_uniform(df["ROI"], 2, 8),
        "Clicks~U(100,1000)": ks_uniform(df["Clicks"], 100, 1000),
        "Impressions~U(1000,10000)": ks_uniform(df["Impressions"], 1000, 10000),
        "Acquisition_Cost~U(5000,20000)": ks_uniform(df["Acquisition_Cost"], 5000, 20000),
    }
    # category independence (Cramer's V)
    vs = []
    for a, b in itertools.combinations(CATS, 2):
        ct = pd.crosstab(df[a], df[b])
        chi2, p, _, _ = stats.chi2_contingency(ct)
        k = min(ct.shape) - 1
        vs.append({"a": a, "b": b, "cramers_v": np.sqrt(chi2 / (len(df) * k)), "p": p})
    vs = pd.DataFrame(vs)
    save_tab(vs.round(5), "categorical_association.csv", index=False)

    dow = df.groupby("DayOfWeek")["ROI"].mean()
    FINDINGS["diagnostics"] = {
        "max_abs_spearman_offdiag": float(offdiag.max().max()),
        "ks_uniform_pvalues": uni,
        "max_cramers_v_between_categoricals": float(vs["cramers_v"].max()),
        "rows_per_date_min_max": [int(df.groupby("Date").size().min()), int(df.groupby("Date").size().max())],
    }
    # Is Conversion_Rate consistent with Clicks/Impressions (no relation expected in this data)?
    FINDINGS["diagnostics"]["spearman_conv_vs_ctr"] = float(stats.spearmanr(df["Conversion_Rate"], df["CTR"])[0])
    FINDINGS["diagnostics"]["spearman_roi_vs_cost"] = float(stats.spearmanr(df["ROI"], df["Acquisition_Cost"])[0])

    fig, axes = plt.subplots(1, 2, figsize=(13, 4.5))
    axes[0].hexbin(df["Acquisition_Cost"], df["ROI"], gridsize=40, cmap="Blues", mincnt=1)
    axes[0].set_xlabel("Acquisition_Cost"); axes[0].set_ylabel("ROI")
    axes[0].set_title("ROI vs Acquisition cost (spend does not buy return)")
    axes[1].hexbin(df["CTR"], df["Conversion_Rate"], gridsize=40, cmap="Blues", mincnt=1)
    axes[1].set_xlabel("CTR (Clicks / Impressions)"); axes[1].set_ylabel("Conversion_Rate")
    axes[1].set_title("Conversion rate vs CTR")
    save_fig("07_cost_vs_roi_and_ctr_vs_conv.png")


# --------------------------------------------------------------------------- 7. time
def time_analysis(df: pd.DataFrame) -> None:
    m = df.groupby("Month").agg(roi=("ROI", "mean"), conv=("Conversion_Rate", "mean"),
                                eng=("Engagement_Score", "mean"), cost=("Acquisition_Cost", "mean"),
                                n=("Campaign_ID", "size")).reset_index()
    save_tab(m.round(4), "monthly_kpis.csv", index=False)
    daily = df.groupby("Date")[["ROI", "Conversion_Rate", "Engagement_Score", "Acquisition_Cost"]].mean()
    trend = {}
    for c in daily.columns:
        r, p = stats.spearmanr(np.arange(len(daily)), daily[c])
        trend[c] = {"spearman_vs_time": round(float(r), 4), "p": round(float(p), 4)}
    dow_groups = [g["ROI"].to_numpy() for _, g in df.groupby("DayOfWeek")]
    mon_groups = [g["ROI"].to_numpy() for _, g in df.groupby("Month")]
    FINDINGS["time"] = {
        "daily_trend_tests": trend,
        "dow_kruskal_p_ROI": float(stats.kruskal(*dow_groups)[1]),
        "month_kruskal_p_ROI": float(stats.kruskal(*mon_groups)[1]),
    }
    fig, axes = plt.subplots(2, 2, figsize=(14, 7))
    for ax, (c, t) in zip(axes.flat, [("roi", "Mean ROI"), ("conv", "Mean Conversion_Rate"),
                                      ("eng", "Mean Engagement_Score"), ("cost", "Mean Acquisition_Cost")]):
        ax.plot(m["Month"], m[c], marker="o", color="#3b6fb6")
        ax.set_title(t + " by month"); ax.tick_params(axis="x", rotation=60)
    save_fig("08_monthly_trends.png")

    order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    dow = df.groupby("DayOfWeek")["ROI"].mean().reindex(order)
    plt.figure(figsize=(8, 4))
    dow.plot(kind="bar", color="#3b6fb6"); plt.ylim(4.9, 5.1)
    plt.title("Mean ROI by day of week (y-axis zoomed: spread is tiny)")
    save_fig("09_roi_day_of_week.png")


# --------------------------------------------------------------------------- 8. modelling
def modelling(df: pd.DataFrame) -> None:
    feats_cat = CATS
    feats_num = ["Conversion_Rate", "Acquisition_Cost", "Clicks", "Impressions", "Engagement_Score",
                 "Duration_Days"]
    X = df[feats_cat + feats_num].copy()
    for c in feats_cat:
        X[c] = X[c].astype("category")
    X["Month_num"] = df["Date"].dt.month
    y = df["ROI"]
    y_cls = (df["ROI"] >= df["ROI"].quantile(0.75)).astype(int)  # "top-quartile ROI"

    Xtr, Xte, ytr, yte, ctr, cte = train_test_split(X, y, y_cls, test_size=0.25, random_state=42)
    reg = HistGradientBoostingRegressor(categorical_features="from_dtype", random_state=42)
    reg.fit(Xtr, ytr)
    base = DummyRegressor().fit(Xtr, ytr)
    r2_model, r2_base = reg.score(Xte, yte), base.score(Xte, yte)
    mae_model = float(np.mean(np.abs(reg.predict(Xte) - yte)))
    mae_base = float(np.mean(np.abs(base.predict(Xte) - yte)))

    clf = HistGradientBoostingClassifier(categorical_features="from_dtype", random_state=42).fit(Xtr, ctr)
    dclf = DummyClassifier(strategy="prior").fit(Xtr, ctr)
    from sklearn.metrics import roc_auc_score
    auc = float(roc_auc_score(cte, clf.predict_proba(Xte)[:, 1]))
    cv_auc = cross_val_score(HistGradientBoostingClassifier(categorical_features="from_dtype", random_state=42),
                             X.sample(60000, random_state=1), y_cls.loc[X.sample(60000, random_state=1).index],
                             cv=5, scoring="roc_auc")

    pi = permutation_importance(reg, Xte.iloc[:20000], yte.iloc[:20000], n_repeats=5, random_state=42)
    imp = pd.Series(pi.importances_mean, index=Xte.columns).sort_values()
    save_tab(imp.rename("permutation_importance_r2_drop").round(6).to_frame(), "model_permutation_importance.csv")

    FINDINGS["model"] = {
        "target_regression": "ROI",
        "test_r2_model": float(r2_model), "test_r2_mean_baseline": float(r2_base),
        "test_mae_model": mae_model, "test_mae_baseline": mae_base,
        "target_classification": "top-quartile ROI (ROI >= %.2f)" % df["ROI"].quantile(0.75),
        "test_auc": auc, "cv5_auc_mean": float(cv_auc.mean()), "cv5_auc_std": float(cv_auc.std()),
        "top_feature_by_permutation": imp.index[-1],
    }
    plt.figure(figsize=(8, 5))
    imp.plot(kind="barh", color="#3b6fb6")
    plt.axvline(0, color="k", lw=0.8)
    plt.title(f"Permutation importance for ROI model\n(test R² = {r2_model:.4f}; baseline = {r2_base:.4f})")
    plt.xlabel("Drop in R² when feature is shuffled")
    save_fig("10_model_permutation_importance.png")


# --------------------------------------------------------------------------- 9. clustering + frontier
def segmentation(df: pd.DataFrame) -> None:
    cols = ["ROI", "Conversion_Rate", "Engagement_Score", "Acquisition_Cost", "CTR"]
    Z = StandardScaler().fit_transform(df[cols])
    samp = RNG.choice(len(Z), 20000, replace=False)
    sil = {}
    for k in range(2, 7):
        km = KMeans(n_clusters=k, n_init=5, random_state=42).fit(Z[samp])
        sil[k] = float(silhouette_score(Z[samp], km.labels_, sample_size=10000, random_state=42))
    FINDINGS["clustering"] = {"silhouette_by_k": sil,
                              "note": "silhouette < ~0.25 means no meaningful cluster structure"}
    plt.figure(figsize=(6, 4))
    plt.plot(list(sil), list(sil.values()), marker="o")
    plt.axhline(0.25, ls="--", color="grey"); plt.xlabel("k"); plt.ylabel("silhouette")
    plt.title("Do natural campaign clusters exist?")
    save_fig("11_clustering_silhouette.png")


def efficiency(df: pd.DataFrame) -> None:
    g = df.groupby(["Company", "Campaign_Type"]).agg(
        avg_cost=("Acquisition_Cost", "mean"), avg_roi=("ROI", "mean"),
        cost_per_conv=("Cost_per_Conversion", "median"), total_profit=("Implied_Profit", "sum"),
        n=("Campaign_ID", "size")).reset_index()
    save_tab(g.round(3), "company_campaigntype_efficiency.csv", index=False)
    plt.figure(figsize=(8, 6))
    sns.scatterplot(data=g, x="avg_cost", y="avg_roi", hue="Company", style="Campaign_Type", s=110)
    plt.title("Company x Campaign_Type: average cost vs average ROI")
    plt.legend(bbox_to_anchor=(1.02, 1), loc="upper left")
    save_fig("12_efficiency_scatter.png")

    tot = df.groupby("Company")["Implied_Profit"].sum().sort_values()
    FINDINGS["profit_by_company_usd_millions_implied"] = (tot / 1e6).round(1).to_dict()


# --------------------------------------------------------------------------- main
def main() -> None:
    df = load()
    audit(df)
    descriptive(df)
    significance(df)
    bootstrap_ci(df)
    combo_search(df)
    diagnostics(df)
    time_analysis(df)
    modelling(df)
    segmentation(df)
    efficiency(df)
    (ROOT / "outputs" / "findings.json").write_text(json.dumps(FINDINGS, indent=2, default=str))
    print(json.dumps(FINDINGS, indent=2, default=str))


if __name__ == "__main__":
    main()
