"""Stage 4 - can any model predict ROI, conversion rate, or a 'high-ROI' flag better than guessing?"""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier, DummyRegressor
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import r2_score, roc_auc_score
from sklearn.model_selection import KFold, StratifiedKFold, cross_val_predict
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from common import *

style()
df = load_data()
NUM = ["Acquisition_Cost_USD", "Clicks", "Impressions", "Engagement_Score", "Duration_Days", "Month", "DayOfWeek"]

def design(drop):
    cats = [c for c in CATS if c != "Duration"]  # Duration is already numeric as Duration_Days
    num = [c for c in NUM + ["Conversion_Rate", "ROI"] if c not in drop]
    X = df[cats + num]
    pre = ColumnTransformer([("c", OneHotEncoder(handle_unknown="ignore"), cats),
                             ("n", StandardScaler(), num)])
    return X, pre

results = []
cv = KFold(5, shuffle=True, random_state=SEED)
for target in ["ROI", "Conversion_Rate"]:
    X, pre = design({target})
    y = df[target]
    models = {"Baseline (predict mean)": DummyRegressor(),
              "Ridge": make_pipeline(pre, Ridge(alpha=1.0)),
              "Gradient boosting": make_pipeline(pre, HistGradientBoostingRegressor(max_iter=200, learning_rate=0.05, random_state=SEED))}
    for name, mdl in models.items():
        pred = cross_val_predict(mdl, X, y, cv=cv)
        results.append({"target": f"{target} (regression)", "model": name, "metric": "R2", "cv_score": r2_score(y, pred)})

y_cls = (df["ROI"] > df["ROI"].median()).astype(int)
X, pre = design({"ROI"})
cvs = StratifiedKFold(5, shuffle=True, random_state=SEED)
models = {"Baseline (prior)": DummyClassifier(strategy="prior"),
          "Logistic regression": make_pipeline(pre, LogisticRegression(max_iter=500)),
          "Gradient boosting": make_pipeline(pre, HistGradientBoostingClassifier(max_iter=200, learning_rate=0.05, random_state=SEED))}
for name, mdl in models.items():
    proba = cross_val_predict(mdl, X, y_cls, cv=cvs, method="predict_proba")[:, 1]
    results.append({"target": "High ROI (> median, classification)", "model": name, "metric": "AUC",
                    "cv_score": roc_auc_score(y_cls, proba)})

# Sanity check on the pipeline itself: a target that IS predictable (CTR from clicks and impressions)
X, pre = design(set())
ctr_X = df[["Clicks", "Impressions"]]
ctr_pred = cross_val_predict(HistGradientBoostingRegressor(random_state=SEED), ctr_X, df["CTR"], cv=cv)
results.append({"target": "CTR from clicks+impressions (positive control)", "model": "Gradient boosting",
                "metric": "R2", "cv_score": r2_score(df["CTR"], ctr_pred)})

res = pd.DataFrame(results)
res.to_csv(RES_DIR / "04_model_results.csv", index=False)
print(res.round(4).to_string(index=False))

# --- figure: cross-validated R2 on a 0-1 scale (with a positive control) and AUC vs chance -----
fig, axes = plt.subplots(1, 2, figsize=(11, 4), gridspec_kw={"width_ratios": [1.5, 1]})
reg = res[res.metric == "R2"].reset_index(drop=True)
yy = np.arange(len(reg))[::-1]
cols = [ORANGE if t.startswith("CTR") else (GREY if "Baseline" in m else BLUE) for t, m in zip(reg.target, reg.model)]
axes[0].barh(yy, reg.cv_score.clip(lower=0), color=cols, height=0.6)
axes[0].set_yticks(yy, [f"{t.split(' (')[0].split(' from')[0]} · {m.replace('Baseline (predict mean)', 'baseline').replace('Gradient boosting', 'GBM')}"
                        for t, m in zip(reg.target, reg.model)], fontsize=8.5)
for yv, v in zip(yy, reg.cv_score):
    axes[0].text(max(v, 0) + 0.012, yv, f"{v:.4f}", va="center", fontsize=8.5, color=INK)
axes[0].set_xlim(0, 1.15)
axes[0].set_xlabel("5-fold cross-validated R² (negative values shown as 0)")
axes[0].set_title("Regression: ROI and conversion rate are unpredictable")
clf = res[res.metric == "AUC"].reset_index(drop=True)
axes[1].bar(range(len(clf)), clf.cv_score, color=[GREY if "Baseline" in m else BLUE for m in clf.model], width=0.55)
axes[1].axhline(0.5, color=ORANGE, lw=1.4)
axes[1].set_ylim(0.4, 0.6)
axes[1].set_xticks(range(len(clf)), ["Baseline", "Logistic", "GBM"])
axes[1].set_ylabel("5-fold AUC")
axes[1].set_title("High-ROI flag: AUC ≈ 0.5 (coin flip)")
fig.tight_layout()
fig.savefig(FIG_DIR / "04_model_performance.png")
