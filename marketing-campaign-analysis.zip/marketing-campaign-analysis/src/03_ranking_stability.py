"""Stage 3 - do "best channel / best campaign type" rankings hold up?
Confidence intervals, split-half replication, a permutation test, and the winner's curse."""
import numpy as np
import pandas as pd
from scipy import stats

from common import *

style()
df = load_data()
rng = np.random.default_rng(SEED)

# --- 1) group means with 95% CIs for ROI ------------------------------------------
ci_rows = []
for c in CATS:
    g = df.groupby(c)["ROI"].agg(["mean", "std", "count"])
    g["se"] = g["std"] / np.sqrt(g["count"])
    for lvl, r in g.iterrows():
        ci_rows.append({"field": c, "level": lvl, "mean_ROI": r["mean"], "ci_low": r["mean"] - 1.96 * r["se"],
                        "ci_high": r["mean"] + 1.96 * r["se"], "n": int(r["count"])})
ci = pd.DataFrame(ci_rows)
ci.to_csv(RES_DIR / "03_roi_group_means_ci.csv", index=False)

# --- 2) permutation test: is the best-vs-worst gap bigger than label shuffling gives? --
y = df["ROI"].to_numpy()
perm = {}
for c in CATS:
    codes, _ = pd.factorize(df[c])
    k = codes.max() + 1
    def gap(lbl):
        sums = np.bincount(lbl, weights=y, minlength=k)
        cnt = np.bincount(lbl, minlength=k)
        m = sums / cnt
        return m.max() - m.min()
    obs = gap(codes)
    null = np.array([gap(rng.permutation(codes)) for _ in range(1000)])
    perm[c] = {"observed_gap": float(obs), "null_median_gap": float(np.median(null)),
               "perm_p": float((1 + (null >= obs).sum()) / (1 + len(null)))}
save_json("03_permutation_tests.json", perm)

# --- 3) winner's curse over 150 audience x type x channel combinations ------------
# Pick the 10 best combos on a random half of the rows, then look at them on the other half.
# A real effect would carry over. Because random halves of one fixed dataset are coupled, the
# result is judged against a noise reference: the same procedure after shuffling ROI across rows.
combo = df["Campaign_Type"] + " | " + df["Channel_Used"] + " | " + df["Target_Audience"]
codes, labels = pd.factorize(combo)
k = codes.max() + 1

def winners_curse(yvec, reps, rng):
    top_b, rho = [], []
    for _ in range(reps):
        mask = rng.random(len(yvec)) < 0.5
        mA = np.bincount(codes[mask], weights=yvec[mask], minlength=k) / np.bincount(codes[mask], minlength=k)
        mB = np.bincount(codes[~mask], weights=yvec[~mask], minlength=k) / np.bincount(codes[~mask], minlength=k)
        top_b.append(mB[np.argsort(mA)[-10:]].mean())
        rho.append(stats.spearmanr(mA, mB).statistic)
    return np.mean(top_b), np.mean(rho)

obs_top_b, obs_rho = winners_curse(y, 20, rng)
null = np.array([winners_curse(rng.permutation(y), 20, rng) for _ in range(200)])
mask = rng.random(len(df)) < 0.5   # one illustrative split for the figure
mA = np.bincount(codes[mask], weights=y[mask], minlength=k) / np.bincount(codes[mask], minlength=k)
mB = np.bincount(codes[~mask], weights=y[~mask], minlength=k) / np.bincount(codes[~mask], minlength=k)
top = np.argsort(mA)[-10:]
curse = {"n_combos": int(k), "rows_per_combo_min": int(np.bincount(codes).min()),
         "overall_mean_ROI": float(y.mean()),
         "illustrative_split": {"top10_mean_ROI_in_half_A": float(mA[top].mean()),
                                "same_top10_mean_ROI_in_half_B": float(mB[top].mean())},
         "observed_top10_in_B_avg_over_20_splits": float(obs_top_b),
         "noise_reference_top10_in_B_mean": float(null[:, 0].mean()),
         "noise_reference_top10_in_B_p5_p95": [float(np.percentile(null[:, 0], 5)), float(np.percentile(null[:, 0], 95))],
         "observed_rank_corr_A_vs_B": float(obs_rho),
         "noise_reference_rank_corr_p5_p95": [float(np.percentile(null[:, 1], 5)), float(np.percentile(null[:, 1], 95))],
         "share_of_noise_runs_with_rank_corr_ge_observed": float((null[:, 1] >= obs_rho).mean())}
save_json("03_winners_curse.json", curse)
print(perm["Target_Audience"], curse)

# --- figures ----------------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(11, 3.9), sharex=True)
for ax, field in zip(axes, ["Campaign_Type", "Channel_Used"]):
    s = ci[ci.field == field].sort_values("mean_ROI")
    yy = np.arange(len(s))
    ax.hlines(yy, s.ci_low, s.ci_high, color=BLUE, lw=2)
    ax.plot(s.mean_ROI, yy, "o", color=BLUE, ms=7, mec="white", mew=1.5)
    ax.axvline(df.ROI.mean(), color=ORANGE, lw=1.2, ls="--")
    ax.set_yticks(yy, s.level)
    ax.set_title(field.replace("_", " "))
    ax.set_xlabel("mean ROI (95% CI)")
axes[0].text(df.ROI.mean() + 0.001, 4.45, "overall mean", color=ORANGE, fontsize=8, va="bottom")
fig.suptitle("Group ROIs differ by a few hundredths, and every interval overlaps the overall mean",
             x=0.01, ha="left", fontsize=12.5, fontweight="bold")
fig.tight_layout()
fig.savefig(FIG_DIR / "03_roi_group_ci.png")

fig, ax = plt.subplots(figsize=(5.4, 5))
ax.scatter(mA, mB, s=22, color=BLUE, alpha=0.75, edgecolor="white", linewidth=0.5)
ax.scatter(mA[top], mB[top], s=40, color=ORANGE, edgecolor="white", linewidth=0.7, zorder=3)
ax.axhline(y.mean(), color=GREY, lw=1)
ax.set_xlabel("combo mean ROI, random half A")
ax.set_ylabel("same combo, half B")
ax.set_title("The 10 'best' combos in half A (orange)\nfall back to the average in half B")
fig.savefig(FIG_DIR / "03_winners_curse.png")
