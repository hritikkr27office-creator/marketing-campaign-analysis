"""Shared helpers: data loading, feature derivation, plotting style, result IO."""
import json
import os
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = Path(os.environ.get("MARKETING_CSV", ROOT / "data" / "marketing_campaign_dataset.csv"))
FIG_DIR = ROOT / "figures"
RES_DIR = ROOT / "results"
FIG_DIR.mkdir(exist_ok=True)
RES_DIR.mkdir(exist_ok=True)

SEED = 42
CATS = ["Company", "Campaign_Type", "Target_Audience", "Duration", "Channel_Used",
        "Location", "Language", "Customer_Segment"]
METRICS = ["ROI", "Conversion_Rate", "Acquisition_Cost_USD", "Engagement_Score", "CTR"]

# Palette (validated default from the dataviz reference): blue = data, orange = highlight, grey = neutral
BLUE, ORANGE, GREY, INK, MUTED = "#2a78d6", "#eb6834", "#b8b7b0", "#0b0b0b", "#52514e"


def load_data() -> pd.DataFrame:
    """Load the raw CSV and return a typed frame with derived KPI columns."""
    df = pd.read_csv(DATA_PATH)
    df["Acquisition_Cost_USD"] = df["Acquisition_Cost"].str.replace(r"[$,]", "", regex=True).astype(float)
    df["Duration_Days"] = df["Duration"].str.extract(r"(\d+)").astype(int)
    df["Date"] = pd.to_datetime(df["Date"])
    df["Month"] = df["Date"].dt.month
    df["DayOfWeek"] = df["Date"].dt.dayofweek
    df["CTR"] = df["Clicks"] / df["Impressions"]
    df["Conversions_Est"] = df["Clicks"] * df["Conversion_Rate"]  # conversions among clicks
    df["Cost_Per_Click"] = df["Acquisition_Cost_USD"] / df["Clicks"]
    return df


def style():
    plt.rcParams.update({
        "figure.dpi": 130, "savefig.dpi": 160, "savefig.bbox": "tight",
        "font.size": 10, "axes.titlesize": 12, "axes.titleweight": "bold",
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.edgecolor": GREY, "axes.labelcolor": MUTED, "xtick.color": MUTED, "ytick.color": MUTED,
        "axes.grid": True, "grid.color": "#e6e5e0", "grid.linewidth": 0.6, "axes.axisbelow": True,
        "text.color": INK, "axes.titlelocation": "left",
    })


def save_json(name: str, obj) -> None:
    (RES_DIR / name).write_text(json.dumps(obj, indent=2, default=float))


def holm(p: np.ndarray) -> np.ndarray:
    """Holm-Bonferroni adjusted p-values."""
    p = np.asarray(p, float)
    order = np.argsort(p)
    m = len(p)
    adj = np.empty(m)
    running = 0.0
    for rank, idx in enumerate(order):
        running = max(running, (m - rank) * p[idx])
        adj[idx] = min(1.0, running)
    return adj


def benjamini_hochberg(p: np.ndarray) -> np.ndarray:
    """Benjamini-Hochberg FDR-adjusted p-values."""
    p = np.asarray(p, float)
    m = len(p)
    order = np.argsort(p)[::-1]
    adj = np.empty(m)
    prev = 1.0
    for i, idx in enumerate(order):
        rank = m - i
        prev = min(prev, p[idx] * m / rank)
        adj[idx] = prev
    return adj
