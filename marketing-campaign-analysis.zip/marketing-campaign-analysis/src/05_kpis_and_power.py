"""Stage 5 - derived KPIs (CTR, CPC, cost per conversion), monthly stability, and statistical power."""
import numpy as np
import pandas as pd
from scipy import stats

from common import *

style()
df = load_data()

# --- ratio-of-sums KPIs per dimension (the correct way to aggregate rates) ----------
def kpis(g):
    cost, clicks, imps = g["Acquisition_Cost_USD"].sum(), g["Clicks"].sum(), g["Impressions"].sum()
    conv = g["Conversions_Est"].sum()
    return pd.Series({"campaigns": len(g), "CTR": clicks / imps, "CPC_usd": cost / clicks,
                      "cost_per_conversion_usd": cost / conv, "mean_ROI": g["ROI"].mean(),
                      "mean_conversion_rate": g["Conversion_Rate"].mean()})

tables = []
for c in ["Channel_Used", "Campaign_Type", "Customer_Segment", "Target_Audience", "Location"]:
    t = df.groupby(c).apply(kpis, include_groups=False).reset_index().rename(columns={c: "level"})
    t.insert(0, "field", c)
    tables.append(t)
kp = pd.concat(tables)
kp.round(4).to_csv(RES_DIR / "05_kpis_by_dimension.csv", index=False)

# spread of each KPI across levels, relative to its overall value
overall = kpis(df)
spread = {m: float((kp[m].max() - kp[m].min()) / overall[m]) for m in ["CTR", "CPC_usd", "cost_per_conversion_usd", "mean_ROI"]}

# --- monthly trend: is there seasonality in ROI or cost? -----------------------------
monthly = df.groupby("Month").agg(ROI=("ROI", "mean"), Cost=("Acquisition_Cost_USD", "mean"),
                                  Conv=("Conversion_Rate", "mean"), n=("ROI", "size"))
monthly.round(4).to_csv(RES_DIR / "05_monthly_means.csv")
season = {m: float(stats.kruskal(*[g[m].values for _, g in df.groupby("Month")]).pvalue)
          for m in ["ROI", "Acquisition_Cost_USD", "Conversion_Rate", "Engagement_Score"]}
dow = {m: float(stats.kruskal(*[g[m].values for _, g in df.groupby("DayOfWeek")]).pvalue)
       for m in ["ROI", "Acquisition_Cost_USD", "Conversion_Rate"]}

# --- power: smallest ROI difference two groups of a given size could reliably detect ----
sd = df["ROI"].std()
z = stats.norm.ppf(0.975) + stats.norm.ppf(0.80)
def mde(n_per_group):
    return z * sd * np.sqrt(2 / n_per_group)
sizes = [500, 2000, 5000, 20000, 40000]
power_tbl = pd.DataFrame({"n_per_group": sizes, "min_detectable_ROI_diff": [mde(n) for n in sizes]})
power_tbl.to_csv(RES_DIR / "05_power_mde.csv", index=False)
largest_gap = float(max(df.groupby(c)["ROI"].mean().max() - df.groupby(c)["ROI"].mean().min() for c in CATS))

summary = {"kpi_relative_spread_across_levels": spread, "overall": overall.to_dict(),
           "month_kruskal_p": season, "weekday_kruskal_p": dow,
           "roi_sd": float(sd), "largest_roi_gap_any_field": largest_gap,
           "mde_table": power_tbl.round(4).to_dict("records")}
save_json("05_kpis_and_power.json", summary)
print(summary["kpi_relative_spread_across_levels"], season, dow)
print(power_tbl.round(3))

# --- figures ---------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(7, 3.8))
ax.plot(monthly.index, monthly.ROI, color=BLUE, lw=2, marker="o", ms=6, mec="white", mew=1.2)
ax.axhline(df.ROI.mean(), color=GREY, lw=1)
ax.set_ylim(0, 8)
ax.set_xticks(range(1, 13), ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"])
ax.set_ylabel("mean ROI")
ax.set_title("No seasonality: monthly ROI sits on the overall mean")
fig.savefig(FIG_DIR / "05_monthly_roi.png")

fig, ax = plt.subplots(figsize=(7, 3.8))
ax.plot(power_tbl.n_per_group, power_tbl.min_detectable_ROI_diff, color=BLUE, lw=2, marker="o", ms=6, mec="white", mew=1.2)
ax.axhline(largest_gap, color=ORANGE, lw=1.4)
ax.text(power_tbl.n_per_group.max(), largest_gap + 0.01, f"largest observed gap in the data: {largest_gap:.3f}",
        color=ORANGE, ha="right", va="bottom", fontsize=9)
ax.set_xscale("log")
ax.set_xticks(sizes, [f"{n:,}" for n in sizes])
ax.minorticks_off()
ax.set_xlabel("rows per group (log scale)")
ax.set_ylabel("smallest detectable ROI difference")
ax.set_title("Power: what a two-group ROI comparison can detect")
fig.savefig(FIG_DIR / "05_power_mde.png")
