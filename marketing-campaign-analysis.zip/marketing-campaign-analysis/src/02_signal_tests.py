"""Stage 2 - is there any real signal? Group tests with multiple-comparison control,
correlations, and independence between every pair of categorical fields."""
import itertools

import numpy as np
import pandas as pd
from scipy import stats

from common import *

style()
df = load_data()
n = len(df)

# --- 8 categorical fields x 5 outcome metrics = 40 Kruskal-Wallis tests --------
rows = []
for c in CATS:
    for m in METRICS:
        groups = [g[m].values for _, g in df.groupby(c)]
        H, p = stats.kruskal(*groups)
        k = len(groups)
        eps2 = max(0.0, (H - k + 1) / (n - k))  # epsilon-squared effect size
        rows.append({"field": c, "metric": m, "H": H, "p_raw": p, "epsilon_sq": eps2})
tests = pd.DataFrame(rows)
tests["p_holm"] = holm(tests.p_raw.values)
tests["q_bh"] = benjamini_hochberg(tests.p_raw.values)
tests.sort_values("p_raw").to_csv(RES_DIR / "02_group_tests.csv", index=False)

# --- correlations --------------------------------------------------------------
num = ["Acquisition_Cost_USD", "ROI", "Conversion_Rate", "Clicks", "Impressions", "Engagement_Score", "CTR"]
pear = df[num].corr()
spear = df[num].corr(method="spearman")
pear.round(4).to_csv(RES_DIR / "02_correlation_pearson.csv")
base = ["Acquisition_Cost_USD", "ROI", "Conversion_Rate", "Clicks", "Impressions", "Engagement_Score"]
off = pear.loc[base, base].where(~np.eye(len(base), dtype=bool)).abs()
max_base = float(np.nanmax(off.values))  # CTR excluded: it is built from clicks/impressions

# --- independence between categorical pairs (Cramer's V) ------------------------
pairs = []
for a, b in itertools.combinations(CATS, 2):
    ct = pd.crosstab(df[a], df[b])
    chi2, p, _, _ = stats.chi2_contingency(ct)
    v = np.sqrt(chi2 / (n * (min(ct.shape) - 1)))
    pairs.append({"a": a, "b": b, "chi2_p": p, "cramers_v": v})
pairs = pd.DataFrame(pairs)
pairs["p_holm"] = holm(pairs.chi2_p.values)
pairs.sort_values("chi2_p").to_csv(RES_DIR / "02_categorical_independence.csv", index=False)

summary = {
    "n_group_tests": int(len(tests)),
    "significant_raw_0.05": int((tests.p_raw < 0.05).sum()),
    "expected_by_chance_0.05": float(0.05 * len(tests)),
    "significant_holm_0.05": int((tests.p_holm < 0.05).sum()),
    "significant_bh_0.05": int((tests.q_bh < 0.05).sum()),
    "largest_epsilon_sq": float(tests.epsilon_sq.max()),
    "smallest_raw_p": tests.sort_values("p_raw").iloc[0][["field", "metric", "p_raw"]].to_dict(),
    "max_abs_pearson_among_base_numeric": max_base,
    "n_categorical_pairs": int(len(pairs)),
    "categorical_pairs_sig_raw": int((pairs.chi2_p < 0.05).sum()),
    "categorical_pairs_sig_holm": int((pairs.p_holm < 0.05).sum()),
    "max_cramers_v": float(pairs.cramers_v.max()),
}
save_json("02_signal_tests.json", summary)
print(summary)

# --- figures -------------------------------------------------------------------
# 1) p-value histogram: real signal piles up near 0; noise is flat
fig, ax = plt.subplots(figsize=(7, 3.8))
ax.hist(tests.p_raw, bins=np.linspace(0, 1, 11), color=BLUE, edgecolor="white")
ax.axhline(len(tests) / 10, color=ORANGE, lw=1.5)
ax.text(0.01, len(tests) / 10 + 0.12, "level expected if nothing is going on", color=ORANGE,
        ha="left", va="bottom", fontsize=9)
ax.set_xlabel("raw p-value (Kruskal-Wallis, 40 field × metric tests)")
ax.set_ylabel("number of tests")
ax.set_title("p-values look like chance: no field moves any metric")
fig.savefig(FIG_DIR / "02_pvalue_histogram.png")

# 2) correlation heatmap, single-hue diverging avoided: values are all ~0 so show |r| on one hue scale
fig, ax = plt.subplots(figsize=(6.6, 5.4))
im = ax.imshow(spear.abs().values, cmap="Blues", vmin=0, vmax=1)
ax.set_xticks(range(len(num)), num, rotation=40, ha="right")
ax.set_yticks(range(len(num)), num)
ax.grid(False)
for i in range(len(num)):
    for j in range(len(num)):
        v = spear.values[i, j]
        ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=8,
                color="white" if abs(v) > 0.55 else INK)
fig.colorbar(im, ax=ax, label="|Spearman r|", shrink=0.8)
ax.set_title("Only built-in links appear (CTR = clicks ÷ impressions)")
fig.savefig(FIG_DIR / "02_correlation_heatmap.png")
