"""Stage 1 - data audit: types, quality, balance, distribution shape, and structure checks."""
import numpy as np
import pandas as pd
from scipy import stats

from common import *

style()
df = load_data()
out = {"rows": len(df), "columns": df.shape[1]}

# --- quality ---------------------------------------------------------------
raw = pd.read_csv(DATA_PATH)
out["missing_cells"] = int(raw.isna().sum().sum())
out["duplicate_rows"] = int(raw.duplicated().sum())
out["duplicate_campaign_ids"] = int(raw["Campaign_ID"].duplicated().sum())
out["ctr_gt_1_rows"] = int((df["CTR"] > 1).sum())
out["date_range"] = [str(df.Date.min().date()), str(df.Date.max().date())]
out["distinct_dates"] = int(df.Date.nunique())

# --- categorical balance: chi-square goodness of fit vs equal frequencies -----
bal = {}
for c in CATS:
    counts = df[c].value_counts()
    chi = stats.chisquare(counts)
    bal[c] = {"levels": int(len(counts)), "min_share": float(counts.min() / len(df)),
              "max_share": float(counts.max() / len(df)), "chi2_p": float(chi.pvalue)}
out["categorical_balance"] = bal

# --- numeric shape: are values flat (uniform) over their range? --------------
shape = {}
for c in ["Acquisition_Cost_USD", "ROI", "Clicks", "Impressions"]:
    u = (df[c] - df[c].min()) / (df[c].max() - df[c].min())
    shape[c] = {"min": float(df[c].min()), "max": float(df[c].max()), "mean": float(df[c].mean()),
                "std": float(df[c].std()), "skew": float(stats.skew(df[c])),
                "ks_uniform_p": float(stats.kstest(u, "uniform").pvalue)}
for c in ["Conversion_Rate", "Engagement_Score"]:  # discrete grids -> chi-square vs equal mass
    vc = df[c].round(2).value_counts()
    shape[c] = {"distinct_values": int(len(vc)), "min": float(df[c].min()), "max": float(df[c].max()),
                "mean": float(df[c].mean()), "std": float(df[c].std()),
                "chi2_uniform_p": float(stats.chisquare(vc).pvalue)}
out["numeric_shape"] = shape

# --- structure: is the row order / date deterministic? ------------------------
expected = pd.Timestamp("2021-01-01") + pd.to_timedelta((df["Campaign_ID"] - 1) % 365, unit="D")
out["date_equals_id_mod_365_pct"] = float((df["Date"] == expected).mean() * 100)
per_day = df["Date"].value_counts()
out["campaigns_per_day_min_max"] = [int(per_day.min()), int(per_day.max())]

save_json("01_data_audit.json", out)

# --- figure: distributions ----------------------------------------------------
fig, axes = plt.subplots(2, 3, figsize=(11, 5.6))
for ax, (c, title) in zip(axes.ravel(), [
        ("Acquisition_Cost_USD", "Acquisition cost ($)"), ("ROI", "ROI"), ("Clicks", "Clicks"),
        ("Impressions", "Impressions"), ("Conversion_Rate", "Conversion rate"),
        ("Engagement_Score", "Engagement score")]):
    bins = 11 if c == "Engagement_Score" else (15 if c == "Conversion_Rate" else 40)
    ax.hist(df[c], bins=bins, color=BLUE, edgecolor="white", linewidth=0.4)
    ax.set_title(title)
    ax.set_yticks([])
fig.suptitle("Every numeric field is flat across its range, a sign of synthetic data", x=0.01, ha="left",
             fontsize=13, fontweight="bold")
fig.tight_layout()
fig.savefig(FIG_DIR / "01_distributions.png")
print(json_summary := {k: out[k] for k in ["rows", "missing_cells", "duplicate_rows", "date_equals_id_mod_365_pct"]})
