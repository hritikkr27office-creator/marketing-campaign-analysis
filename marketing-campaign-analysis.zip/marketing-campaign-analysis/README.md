# Marketing Campaign Performance — Statistical Audit & Predictive Analysis

An extended analysis of the *Marketing Campaign Performance* dataset (200,000 campaigns, 5 companies, 2021).

Public work on this dataset is mostly **descriptive**: cleaning, group-by KPIs (ROI, conversion, engagement, cost by
type/channel/audience/location) and dashboards (Power BI, KNIME, Kaggle EDA notebooks). This project covers the
questions those leave open: *are the differences between segments real, can anything predict ROI, and is the data
trustworthy enough to base budget decisions on?*

> **Headline result:** across 56 segment-vs-metric tests, **none** are statistically significant after multiple-testing
> correction, a gradient-boosting model cannot predict ROI better than guessing the average, and the data behaves like
> independent random draws. The differences you see in dashboards are noise.

## What was already covered vs. what this repo adds

| Area | Typical existing work | This repo |
|---|---|---|
| Cleaning (`$` cost to number, dates) | ✅ | ✅ |
| Group-by KPI tables / dashboards | ✅ | ✅ (`outputs/tables/segment_kpis.csv`) |
| Derived KPIs (CTR, CPC, cost per conversion, implied profit) | rarely | ✅ |
| Data-integrity audit (type vs. channel logic, duplicates, ranges) | rarely | ✅ |
| Significance tests + effect sizes, BH-corrected | ❌ | ✅ |
| Bootstrap confidence intervals | ❌ | ✅ |
| "Best combination" tested against a permutation null | ❌ | ✅ |
| Independence / uniformity diagnostics | ❌ | ✅ |
| Time-series trend, seasonality, day-of-week tests | ❌ | ✅ |
| ROI prediction with held-out test + baseline | ❌ | ✅ |
| Clustering / natural segments | ❌ | ✅ |

*Caveat on this table:* the right-hand "existing work" column is based on the dashboards/notebooks I could find
(Power BI project, KNIME template, several Kaggle notebook titles). Several Kaggle notebook bodies were not readable,
so some may already include parts of the "❌" items.

## Key findings

| Question | Result |
|---|---|
| Data quality | 200,000 rows, 0 missing, 0 duplicates, unique IDs, no Clicks > Impressions |
| Does Campaign_Type match Channel_Used? | **No.** Email campaigns run on YouTube/Google Ads etc. 29.97% of rows are Email-type-on-non-Email-channel or the reverse. Type and channel are statistically independent (Cramér's V = 0.005). |
| Do segments differ? | 0 of 56 tests significant after Benjamini–Hochberg. Largest effect size (η²) = 0.00005, i.e. 0.005% of variance. |
| Best Type × Channel × Audience combo | Influencer / Facebook / Women 25–34: ROI 5.135 vs 5.002 overall. Permutation p = 0.33, **no better than the best of 150 random shuffles.** |
| Time | No significant trend in ROI, conversion or engagement. Month and day-of-week effects not significant. |
| Predicting ROI | Test R² = −0.0002 (baseline −0.00001); classifying top-quartile ROI AUC = 0.50 (5-fold CV 0.500 ± 0.006). |
| Natural clusters | Silhouette ≤ 0.17 for k = 2–6, no cluster structure. |
| Spend vs return | Spearman(ROI, cost) = 0.005. Spending more does not relate to ROI. |
| Funnel consistency | Spearman(Conversion_Rate, CTR) = 0.0008. Funnel metrics are unrelated. |

### What this means
- Distributions are close to uniform (ROI~U(2,8), Clicks~U(100,1000), etc.; KS tests do not reject), and every column is
  uncorrelated with every other. This is characteristic of **synthetic data**. It is excellent for practising pipelines,
  but conclusions like "Facebook is the best channel" would not be supported by it.
- For a real business the recommended next step would be to run the same pipeline (`src/analysis.py`) on actual campaign
  data. The tests, bootstrap CIs, permutation check and baseline-vs-model comparison transfer unchanged.

## Figures
| | |
|---|---|
| ![](outputs/figures/03_significance_and_effect_size.png) | ![](outputs/figures/05_best_combo_vs_permutation_null.png) |
| ![](outputs/figures/04_bootstrap_roi_ci.png) | ![](outputs/figures/01_campaign_type_vs_channel.png) |
| ![](outputs/figures/10_model_permutation_importance.png) | ![](outputs/figures/08_monthly_trends.png) |

All 12 figures are in `outputs/figures/`, all tables in `outputs/tables/`, and the raw numbers in `outputs/findings.json`.

## Method notes
- `Acquisition_Cost` parsed from `"$16,174.00"`; `Duration` parsed to days.
- **Assumption:** ROI = (revenue − cost) / cost, so implied profit = ROI × cost. The dataset does not define ROI.
- Tests: one-way ANOVA and Kruskal–Wallis per dimension × metric (8 × 7 = 56); Kruskal p-values BH-adjusted; η² effect size.
- Permutation null: shuffle ROI 200 times, record the best combo's mean each time (combos with n ≥ 100).
- Model: `HistGradientBoosting` (regression on ROI; classification on top-quartile ROI), 75/25 split, permutation importance.
- Seeds fixed (`42`), so results are reproducible.

## Run it
```bash
pip install -r requirements.txt
python src/analysis.py        # ~40 seconds; writes outputs/
```

## Repository layout
```
data/marketing_campaign_dataset.csv   source data (27 MB)
src/analysis.py                       full pipeline
outputs/figures/                      12 charts
outputs/tables/                       10 CSV tables
outputs/findings.json                 every headline number above
```

## Limitations
- Findings describe *this* dataset; the data looks synthetic, so they should not be generalised to real campaigns.
- ROI is undefined in the source; implied-profit figures depend on the stated assumption.
- Only 200 permutations were used (permutation p-value resolution ≈ 0.005).
